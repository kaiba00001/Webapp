using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication1.Pages
{
    public class checkinModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
